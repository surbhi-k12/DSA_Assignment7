package in.ineuron;

public class DSA_4Reverse {
	
	    public static String reverseWords(String s) {        
	        String arr[] = s.split(" ");
	        StringBuilder sb = new StringBuilder();
	        for(String x : arr) {
	            sb.append(reverse(x)).append(" ");
	        }
	        return sb.toString().trim();
	    }
	    public static String reverse(String s) {
	        int i = 0;
	        int j = s.length() - 1;
	        char arr[] = s.toCharArray();
	        while(i < j) {
	            char temp = arr[i];
	            arr[i] = arr[j];
	            arr[j] = temp;
	            i++;
	            j--;
	        }
	        return new String(arr);
	    }
	    public static void main(String[] args) {
			
	    	String result;
	    	
	    	String input="Let's take LeetCode contest";
	    	result=reverseWords(input);
	    	System.out.println(result);
		}
	}



